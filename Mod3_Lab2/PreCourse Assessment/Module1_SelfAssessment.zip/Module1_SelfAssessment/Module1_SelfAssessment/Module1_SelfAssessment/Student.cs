﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module1_SelfAssessment
{

    public class Student
    {
        public string Name { get; set; }
        
        public int ID { get; set; }
        
        public Student(string name, int id)
        {
            name = this.Name;
            id = this.ID;
        }
        public Student(string name)
        {
            name = Name;
        }

    }
}
