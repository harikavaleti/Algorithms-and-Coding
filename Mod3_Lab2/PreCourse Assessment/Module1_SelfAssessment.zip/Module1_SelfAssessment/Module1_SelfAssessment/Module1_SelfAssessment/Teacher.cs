﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module1_SelfAssessment
{
    public class Teacher
    {
        public string Name { get; set; }

        public String Department { get; set; }
        
        public Teacher(string Name, string department)
        {
            Name = this.Name;
            department = Department;
        }
        public Teacher(string Name)
        {
            Name = this.Name;
        }
   
    }
}
